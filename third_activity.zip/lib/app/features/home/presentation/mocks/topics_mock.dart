class TopicsMock {
  const TopicsMock({
    required this.title,
    required this.remainingTime,
  });
  final String title;
  final String remainingTime;
}
