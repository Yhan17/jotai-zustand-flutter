class AppDimensions {
  AppDimensions._();
  static const double svgHeaderHeight = 250;
}
