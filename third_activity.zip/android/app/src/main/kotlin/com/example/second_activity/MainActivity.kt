package com.example.second_activity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
