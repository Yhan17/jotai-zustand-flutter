package dev.isar.isar_flutter_libs;

import androidx.annotation.NonNull;

import io.flutter.embedding.engine.plugins.FlutterPlugin;

public class IsarFlutterLibsPlugin implements FlutterPlugin { 
    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding flutterPluginBinding) { }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) { }
}
