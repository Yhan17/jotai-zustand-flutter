#import <Flutter/Flutter.h>

@interface IsarFlutterLibsPlugin : NSObject<FlutterPlugin>
@end
